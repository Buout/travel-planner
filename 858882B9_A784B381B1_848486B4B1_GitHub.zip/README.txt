Extract the archive, upload index.html to the root of the GitHub repository Buout/travel-planner. Do not upload the ZIP itself.
